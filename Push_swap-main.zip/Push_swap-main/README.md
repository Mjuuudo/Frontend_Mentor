# PushSwap
## What is push_swap
*`Push_swap`*: is a project which you should sort a _stack_ (a) using another _stack_ (b).
## Stack
stack: is an abstract data type, where the first in last out.
stack like a sets of book, when you put one atop another you can access to any data befor move all data befor it.
## Move 
`sa`: swap stack a (first become second and second become frist)

`sb`: swap stack b

`ss`: swap both of this stacks

`ra`: rotate stack a (first go to bottom of stack)

`rb`: rotate stack b

`rr`: rotate both of this stacks

`rra`: reverse rotate stack a (last go to top)

`rrb`: reverse rotate stack b

`rrr`: reverse rotate both of this stacks

## Algorithm
I chose an algorithm to sort this stack called the Turk algorithm.
My expirence with this algorithm was good, but you should keep mind that this algorithm are so long (check my so_long 😁/https://github.com/adamkhobba/so_long_mac) in its implementation.
## Resources
- https://medium.com/@ayogun/push-swap-c1f5d2d41e97 (Article)
- https://youtu.be/wRvipSG4Mmk?si=I9MLXedI6xE5VOlf (video)
# checker (bonus)
# what is checker
*`Checker`*: is a program that take moves form any stdin, this checker is created to be check in the stack is sorted using a given moves form stdin (push_swap).

